public class Strings {

    public static void main(String[] args){

        // Cadenas de texto

        String name = "hola";
        var surname = new String("hela");

        // operaciones basicas
        System.out.println(name);
        System.out.println(name+surname);
        //Concatenacion
        System.out.println(name+" "+surname);

        //logitud

        System.out.println(name.length());



    }
}
